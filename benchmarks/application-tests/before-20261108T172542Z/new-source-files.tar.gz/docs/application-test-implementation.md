# Anwendungstest-Implementierung

Arbeitsbeginn: 2026-11-08. Ausgangs-HEAD:
`789454f22f8fb8bda3d203759ebfb28d3d10be92` (vor Umsetzung erneut prüfen).
Architekturentscheidungen und Referenzlisten bleiben in
[Konzept](application-test-concept.md) und [Migration](application-test-migration.md).

## Auftrag und unveränderliche Grenzen

P0–P7 bilden den Gesamtauftrag. Go kommt vor Bun und Rust; Java behält seine
bisherigen Fähigkeiten. Bestehende Adapterkonfigurationen bleiben unterstützt.
`ProgramPlan` und `case_manifest` bestimmen Inputs und Pflichtumfang für beide
Backends. Eine neue Backendwahl verändert weder Fall-IDs noch Seeds/Budgets.
Neue diagnostische Pläne oder importierte Urteile erhalten keine Übernahmeautorität.
Automatisches Skipping und allgemeine historische PASS-Wiederverwendung bleiben aus.

## Aktuelle Priorität des Nutzers (2026-11-08)

Der Nutzer hat die tatsächliche Umstellung des Cinema-Projekts als ersten Test
priorisiert und verlangt, die aktuelle Validierung vorab festzuhalten und danach
mit dem Umbau zu vergleichen. Entsprechend der akzeptierten Reihenfolge beginnt
die Ausführung mit `examples/cinema-go`; die gemeinsame Cinema-Spezifikation
bleibt unverändert. Der P0-Planexport allein erfüllt diese Umstellung nicht.
Die übrigen P0–P7-Ziele bleiben erhalten; die native Cinema-Strecke hat Vorrang.

Vor weiteren Änderungen an Rust-, Go- oder Skriptquellen wird die laufende
korrigierte vollständige Validierung abgeschlossen und als separate
Migrationsreferenz gesichert. Dies ist keine Promotion von
`benchmarks/baseline.json`. Die Referenz benötigt den vollständigen Messdatensatz,
Coverage-Rohmetriken und die tatsächlich erfassten Produktionsdateien, native
Go-/Rust-Abnahmeberichte, CLI-/Quellhashes sowie den reproduzierbaren Dirty-Stand
(Basisrevision, Patch und neue Quelldateien). Nach dem Umbau werden dieselben
Pflichtfälle, Seeds, Budgets, fachlichen Urteile, Mutationen und Replay sowie
Build-/Laufzeit, RSS, Artefaktvolumen und handgeschriebene Anschlussstellen
verglichen. Zusätzliche Konformitätsproben werden separat ausgewiesen.

Die ersten direkten Go-Testanschlüsse sind `domain.Validate`,
`domain.CandidateOrderWinner` und `persistence.Store.Invoke` mit tatsächlichem
SQLite-Store. `Store.Invoke` ist die bestehende Produktionsschnittstelle;
sie rechtfertigt keinen neuen projektspezifischen Worker-Dispatcher im Test.
Die Testbibliothek übernimmt Registrierung, Falliteration und Finalisierung;
der zentrale Rust-Bewerter behält Urteil, Setup-Datenfluss und Fortsetzungen.
Die bisherigen Adapterdateien bleiben für Vergleich und noch nicht umgestellte
Bereiche erhalten. Die vollständige Umstellung darf nicht als bestanden gelten,
solange Pflichtbereiche oder native Testformen unimplementiert bleiben.

## Übernommener Arbeitsstand

Vorhandene Änderungen: README, Stringgenerierung, Projektionsprüfung von
Setup-Platzhaltern, Operation-Argument- und Stringtests; neue
`projection/setup_arguments.rs` sowie beide Konzeptdokumente. Diese Änderungen
werden erhalten. Setup-Bindungen müssen auch im Export und bei Fortsetzungen
vollständig erhalten bleiben; tatsächliche Inputs werden nach Auflösung geprüft.

## Etappen und Abnahme

| Etappe | Ergebnis | Stand |
| --- | --- | --- |
| P0 | Versionierter gemeinsamer Export, eindeutige Gruppen, Konfiguration und Vergleichsbasis | Plan/Zuordnung implementiert; native Vergleichsbasis offen |
| P1 | Go-Testbibliothek und zentrale reine Bewertungssitzung mit getrenntem Protokoll | Offen |
| P2 | Zustand, Calls, Ressourcen, lokale Fortsetzungen, persistenter Lifecycle | Offen |
| P3 | Collector, Quellbindung, Gruppenevidenz, Store-Guards, Replay/Mischbetrieb | Offen |
| P4 | Bun/Rust und vollständige Cinema-Abnahme | Offen |
| P5 | Vollständiges Consumer-Paket `runner/internal/preparedplans` | Offen |
| P6 | Transitive Testanalyse und eingefrorene Auswahlvorhersagen, kein Skipping | Offen |
| P7 | Belegter freiwilliger Rückbau, Dokumentation und Distribution | Offen |

## Geprüfte Einstiegspunkte

- `manifest::case_manifest`: einzige zentrale Fallinventarisierung.
- `projection::ProgramPlan`, `OperationPlan::generated_setup`,
  `projection/setup_arguments`: vollständige Plan- und Setup-Daten erhalten.
- `verification_setup::VerificationConfiguration`: heutiges Format Version 1
  verlangt einen Adapter; bestehende Ausführungswege dürfen kein neues Format
  stillschweigend als Adapterkonfiguration behandeln.
- `verification_run::{execution,adoption}`: bestehende Manifest-/Übernahmeprüfung
  bleibt bis zur gesonderten Gruppenabnahme maßgeblich.

## Evidenz und technische Grenzen

Noch keine neue native Ausführung, Vergleichsmessung oder Gesamt-Abnahme.
Performance und mindestens 97 % Rust-Linien-/Funktionscoverage sind für die
integrierte Abnahme erforderlich; die akzeptierte Baseline wird nicht verändert.
Native Testquellen können Beobachtungen fälschen; der Auftrag verspricht keine
kryptografische Ehrlichkeitsprüfung beliebigen Anwendungscodes.

## Implementierte P0-Schnittstelle

`dctx0_verification::application_plan::application_test_plan` übernimmt den
unveränderten `ProgramPlan` und dessen zentrales Manifest. Exakte Pflicht-IDs
selektieren ganze Fälle. Jede Pflicht besitzt genau eine Gruppe; alle Pfade
eines Lifecycle gehören derselben Gruppe. Szenarien bleiben einzelne atomare
Manifestfälle. Identitätsfälle bleiben zentrale, aus tatsächlichen Quellfällen
abzuleitende Pflichten; die Zuordnung allein liefert keine Identitätsevidenz.

Die Testformen Decoder, Operation, StateChange, Scenario, Lifecycle, Assertion
und EntityIdentity werden ausschließlich für vorhandene Manifestfälle abgeleitet.
Eine Registrierung mit unpassender Testform wird zurückgewiesen. Native
Katalogenumeration und Ausführungsabschluss sind noch nicht implementiert.
Unterschiedliche Ressourcennamensräume sind Konfiguration, kein Nachweis echter
Isolation. Target-Namen in diesem diagnostischen Plan schalten keine Fähigkeit frei.

Der CLI-Zugang ist eine explizite Erweiterung von `verify plan`:

```sh
dctx0 verify plan SPEC --subject QUALIFIED_SUBJECT \
  --application-tests groups.json --test-catalog catalog.json --json
```

Beide Dateien sind jeweils auf 512 KiB begrenzt. `groups.json` hat diese Form
(die Fallmenge ist für den konkret veröffentlichten Plan vollständig anzugeben):

```json
{
  "schema_version": 2,
  "groups": [{
    "id": "year", "backend": "application-tests", "target": "go",
    "selection": ["TestReleaseYear"],
    "area": {"cases": [], "requirements": ["W.ReleaseYear"]},
    "resources": {
      "namespace": "year", "timeout_seconds": 60,
      "max_message_bytes": 1048576
    }
  }]
}
```

Der Katalog ist ein Array von Registrierungen mit `group`, `test`, `form` und
`cases` (exakte Fall-IDs aus dem zentralen Manifest). Beispielsweise lautet die
Testform für einen Decoder `"decoder"`. Jede ausgewählte native Testidentität
muss registriert sein; jeder ihr zugeordnete Fall wird genau einmal registriert.
Adaptergruppen haben `backend: "adapter"` und eine einzelne Adapteridentität in
`selection`; sie besitzen keine Anwendungstestregistrierungen.

| Format | Leser/Schreiber | Verhalten |
| --- | --- | --- |
| Bestehende `verification.json`, Schema 1 | Bestehende Setup-/Ausführungswege unverändert | Adapter; keine Migration |
| Gruppen, Schema 2 | Explizites `--application-tests` und reine Bibliotheks-API | Nur diagnostische Planung; unbekannte Versionen abgelehnt |
| Anwendungstestexport, Schema 1 | `ApplicationTestPlan` und `validate()` | Originalplan, Manifest, Konfiguration, Zuordnung, Testformen, Registrierungen |
| SDK 2 / Worker-Protokoll 1 | Bestehender Adapterpfad unverändert | Keine Protokolländerung |
| Run-/Store-Formate | Unverändert | Keine neue persistente Evidenz oder Übernahmeautorität |

`ApplicationTestPlan::validate()` berechnet Manifest, Testformen und Zuordnung
erneut. Ein editierter Export kann diese Ableitungen nicht ersetzen. Das ist
keine Quell-/Buildbeglaubigung: diese entsteht erst im Collector-/Store-Inkrement.
Die neue Konfiguration wird nicht automatisch aus `verification.json` gelesen;
bewachte Ausführung und ein gemeinsamer Konfigurationsleser gehören noch zu P3.

## Ausführbare Gegenproben

`crates/dctx0-verification/tests/application_tests.rs` prüft die vollständige
Cinema-Projektion mit direkten Bereichen für ReleaseYear, candidateOrderWinner
und FilmCatalogStore.save sowie einem unabhängigen Adapterrest. Originalplan,
Manifest, Budgets und offene Pflichten sind in beiden Konfigurationen identisch.
Dies ist Planvergleich, kein nativer Alt-/Neu-Ausführungsvergleich.

Weitere Gegenproben decken Lücken, Überschneidungen, unbekannte IDs,
Registrierungsduplikate, unpassende Testformen, geteilte Lifecycle-Pfade,
Versionsfehler und editierte Exportableitungen ab. Der Setup-Roundtrip wird in
`tests/operation_arguments.rs` einschließlich späterer Argumentauflösung geprüft.
Der CLI-Test prüft JSON/Markdown, Größenlimits und unveränderte History.

Der gemeinsame Messrunner enthält die Release-Phase `application-test-plan`.
Sie misst Export/Zuordnung nach vorbereiteter Projektion; RSS umfasst den Prozess
einschließlich Vorbereitung. Native Build-/Laufkosten und handgeschriebener
Anschlussaufwand sind erst nach P1 vergleichbar und bleiben offen.

## Vorinventar des festgelegten Consumers (nur lesend)

Am 2026-11-08 wurden die Root- und Runner-`AGENTS.md` sowie die öffentlichen
Grenzen von `runatron-business/packages/runner/internal/preparedplans` gelesen.
Der dabei gelesene Consumer-HEAD lautet
`1067ab10dae944865de99103ddf12e5f8e13ceee`; dies beglaubigt keinen unveränderten
Consumer-Arbeitsbaum. Im Consumer wurden keine Dateien geändert und keine
Prüfungen ausgeführt.

| Grenze | Vorhandene Implementierung/Anschluss |
| --- | --- |
| Öffnen und Bindung | `Open`, `OpenObserved`, `BelongsTo`; unveränderliche Registrierung |
| Datensatzspeicherung und Sicht | `Save`, `Snapshot`, `Get`; gesperrter Writer nach unbestätigtem Commit |
| Publikation | `Publish`, `Stage`, `Confirm`, `Fence`, `Receipt`, `Effective` |
| Persistenzport | `SnapshotStorage.Read/Commit`; tatsächliche Implementierung über `gitworkspace.NewSizedSnapshotFile` |
| Vorhandene Spec-Pflicht | `RunatronBusiness.RunnerRuntime.PreparedPlans.save` und Entity `PreparedPlanRecord`, `spec/runner-runtime/transaction-ports.dctx0` |
| Bestehender Adapter | `.dctx0/testing/go/prepared-plans.go`: `ensurePreparedStore`, `invokePreparedSave`, `observePrepared` |
| Echte Fixture | Eigener `gitworkspace.Root`, Snapshot-Limit 8 MiB, `OpenObserved` für Ressourcen und `Store.Snapshot` für Zustand |

Die vorhandene Save-Pflicht fordert tatsächliches Lesen/Schreiben, Einfügen,
`result == request` bei Erfolg und unveränderten Zustand bei Fachfehlern. Der
Adapter übersetzt `StateConflict` als deklarierten Fehler; Codecfehler bleiben
Adapterfehler und Storagefehler Umgebungsfehler. Diese Unterscheidung ist bei
der Migration zu erhalten. Die übrigen öffentlichen Go-Methoden sind nicht
automatisch eigenständige Spec-Operationen: ihre vorhandenen nativen Prüfungen
bleiben Pflichtumfang des vollständigen Pakets.

15 vorhandene native Tests verteilen sich auf `store_test.go`,
`publication_test.go`, `observed_boundaries_test.go` und
`reopen_boundaries_test.go`. Sie enthalten tatsächliches Wiederöffnen, verlorene
Commitbestätigungen, Duplikate/Parallelität, unbestätigte Publikation,
Cancellation, beobachteten Write-Fehler und manipulierte Snapshotdaten.
Die bestehenden Helpers `openDisk`, `publication`, `faultSnapshot` und
`cancellationSnapshot` sind Wiederverwendungskandidaten; sie wurden hier nicht
als vollständige neue Library-Anbindung abgenommen. Übergreifende Host-/Event-
und Configuration-Szenarien verwenden ebenfalls `preparedplans.Store` und
müssen bei der späteren Gruppenzuordnung als verbundene Fälle erhalten bleiben.

## Validierung dieses Arbeitsstands

Gestartet wurde `python3 scripts/validate.py --coverage --samples 1 --iterations 1`.
Das vollständige Log liegt in `target/application-test-validation.log`.
Ein Sample/eine Iteration sind Entwicklungsbedingungen; ein Vergleich gegen die
akzeptierte Baseline ist damit unbewertet. Die Baseline wird nicht promoviert.

Bereits erfolgreich: Workspace-Check, Build, rustfmt, Clippy mit `-D warnings`,
703 Workspace-Rust-Tests (Benchmarkkonformität folgt gemäß Runner am Ende),
CLI ohne Standardfeatures sowie Rust-only und Go-only, 46 Python-Tests,
46 Bun-Tests, native Go-Tests/vet und Go-Race. Die Workspace-Prüfung enthält
den vollständigen Cinema-Test mit Replay und HTTP-Mutation.

Die vollständigen bestehenden Go-/Rust-Cinema-Abnahmen bestehen ebenfalls:
jeweils 5.766 Fälle, 105 Tasks, fünf reale Mutationen und Replay. Dies ist
Kompatibilitätsevidenz des bisherigen Backends, keine Ausführung des neuen
Anwendungstestmodells.

Der erste Lauf wurde nach dem Coverage-Export vor den Release-Messungen beendet:
Der Standardfilter von cargo-llvm-cov hatte die neue Produktionsdatei
`application_tests.rs` wegen ihres Namens ausgelassen. Die nominellen 97,07 %
sind damit keine akzeptierte Coverage dieses Inkrements. Der reine Planer liegt
nun in `application_plan.rs`; die Gegenproben bleiben unter `tests/`.
`application_plan` ist auch der Name des neuen Rust-Moduls. Der separate
Abbruchbeleg steht in `application-test-validation-interrupted.json`, die
ursprünglichen Rohdaten unter `target/application-test-before-rename/`.

Die Wiederholung verwendet das im Repository dokumentierte serielle QA-Profil:
dev/test opt-level 1, keine Debugsymbole oder inkrementelle Kompilierung,
Debug-Assertions und Overflow-Prüfungen bleiben explizit aktiviert. Die
uninstrumentierten Release-Messungen bleiben separat. Noch laufend: erneute
vollständige Validierung, Coverage mit erfasstem Produktionsmodul und gekoppelte
Release-Messungen. Bis zum Abschluss ist dies keine vollständige Abnahme.

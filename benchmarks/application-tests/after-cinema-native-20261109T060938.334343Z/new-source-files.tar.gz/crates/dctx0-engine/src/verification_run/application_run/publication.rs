//! Bridge actual managed application execution into the existing native task
//! transaction. Replay and imported/served reports never invoke this bridge.
use super::*;
use dctx0_verification::application_evidence::{
    APPLICATION_EXECUTION_MEDIA_TYPE, ApplicationExecutionProof, ApplicationPhaseProof,
};

impl Project {
    #[allow(clippy::too_many_arguments)]
    pub async fn verify_application_tests(
        &self,
        application: &Path,
        plan: &str,
        group: &str,
        recipe: &str,
        output: &str,
        cancel: &NativeCancellation,
        no_adopt: bool,
    ) -> Result<ApplicationNativeReport> {
        let (root, bundle, _) = self.read_application_testing_bundle(application, plan)?;
        let (_, config) = self.verification_configuration(Some(&root))?;
        let program = &bundle.plan.program;
        let snapshot = self.load(&program.snapshot)?;
        // Capture before running any application code, never from a saved PASS.
        let (pin, mut incomplete) = pins::capture(self, &root, &config.target, program, &snapshot)?;
        let verifier = crate::native::VerifierIdentity::capture()
            .map_err(|error| Error::Invalid(error.to_string()))?;
        let started_at_unix_ns = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .map_err(|error| Error::Invalid(error.to_string()))?
            .as_nanos()
            .to_string();
        let started = Instant::now();
        let mut report = self
            .run_application_tests(&root, plan, group, recipe, output, cancel)
            .await?;
        let _lock = self.lock()?;
        if report.source_inputs != Capture::application_inventory(&root, config.capture_budgets())?
            || digest(&serde_json::to_vec(
                &self.read_application_testing_bundle(&root, plan)?.1,
            )?) != report.plan_hash
            || dctx0_changes::source_hash(&self.sources()?) != snapshot.source_hash
        {
            incomplete.push(issue(
                "ADOPTION_INPUTS_CHANGED",
                "Source inputs or requirements changed before publication",
            ));
        }
        if verifier
            != crate::native::VerifierIdentity::capture()
                .map_err(|error| Error::Invalid(error.to_string()))?
        {
            incomplete.push(issue(
                "ADOPTION_VERIFIER_CHANGED",
                "Managing verifier identity changed",
            ));
        }
        for phase in &report.phases {
            // Temporary test binaries were checked while the capture still
            // existed. After cleanup retain their actual materialized hash;
            // external runtimes must additionally remain current at publication.
            let current = match Path::new(&phase.runtime.executable_path)
                .strip_prefix(&report.captured_root)
            {
                Ok(relative) => {
                    report
                        .materialized_inputs
                        .get(&relative.to_string_lossy().replace('\\', "/"))
                        == Some(&phase.runtime.executable_hash)
                }
                Err(_) => phase.runtime.still_current().unwrap_or(false),
            };
            if !current {
                incomplete.push(issue(
                    "ADOPTION_RUNTIME_CHANGED",
                    format!("{} runtime changed", phase.phase),
                ));
            }
        }
        incomplete.extend(report.issues.clone());
        if cancel.is_cancelled() {
            incomplete.push(issue(
                "ADOPTION_CANCELLED",
                "Cancelled executions cannot deliver tasks",
            ));
        }
        let manifest = dctx0_verification::case_manifest(program);
        let mut artifacts = vec![
            VerificationArtifact::new(
                "application/vnd.dctx0.plan+json",
                serde_json::to_vec(program)?,
            ),
            VerificationArtifact::new(
                "application/vnd.dctx0.case-manifest+json",
                serde_json::to_vec(&manifest)?,
            ),
            VerificationArtifact::new(
                "application/vnd.dctx0.captured-input-inventory+json",
                serde_json::to_vec(&report.source_inputs)?,
            ),
            VerificationArtifact::new(
                "application/vnd.dctx0.application-native-receipt+json",
                serde_json::to_vec(&report)?,
            ),
            VerificationArtifact::new(
                "application/vnd.dctx0.verifier-identity+json",
                serde_json::to_vec(&verifier)?,
            ),
            VerificationArtifact::new(
                "application/vnd.dctx0.assessment-version+json",
                serde_json::to_vec(
                    &serde_json::json!({"schema_version":1,"version":dctx0_verification::application_session::APPLICATION_ASSESSMENT_VERSION}),
                )?,
            ),
        ];
        if let Some(phase) = report
            .phases
            .iter()
            .find(|phase| phase.phase == "native-tests")
        {
            artifacts.push(VerificationArtifact::new(
                "application/vnd.dctx0.runtime-identity+json",
                serde_json::to_vec(&phase.runtime)?,
            ));
        }
        let mut run = VerificationRun {
            schema_version: 1,
            origin: VerificationRunOrigin::Native,
            started_at_unix_ns,
            elapsed_us: started.elapsed().as_micros().min(u64::MAX as u128) as u64,
            provenance: VerificationProvenance {
                snapshot: program.snapshot.clone(),
                check_occurrence: program.check_occurrence as i64,
                plan_hash: artifacts[0].reference.hash.clone(),
                implementation: report.source_inputs.clone(),
                dependencies: report.materialized_inputs.clone(),
                adapter_hash: report.plan_hash.clone(),
                configuration_hash: digest(&serde_json::to_vec(&(
                    &config,
                    &bundle.plan.configuration,
                ))?),
                harness_hash: artifacts[3].reference.hash.clone(),
                interpreter_version: dctx0_interpreter::INTERPRETER_VERSION.into(),
                generator_version: program.generator_version.clone(),
                protocol_version:
                    dctx0_target_sdk::application_protocol::APPLICATION_PROTOCOL_VERSION,
                target: config.target.clone(),
                runtime_version: String::new(),
                build_configuration: report.build_inputs.clone(),
                task_pin: pin,
                incomplete,
            },
            budgets: program.budgets.clone(),
            selected_subjects: program.scope.subjects.clone(),
            required_subjects: program.closure.clone(),
            not_selected: program.not_selected.clone(),
            required_cases: manifest.required_cases.clone(),
            cases: report
                .assessment
                .as_ref()
                .map(|assessment| assessment.cases.clone())
                .unwrap_or_default(),
            open_obligations: manifest.open_obligations.clone(),
            bounded_obligations: manifest.bounded_obligations.clone(),
            artifacts: vec![],
            result: report.result.clone(),
        };
        if let Some(assessment) = &report.assessment {
            let proof = ApplicationExecutionProof {
                schema_version: 1,
                plan: bundle.plan.clone(),
                assessment: assessment.clone(),
                source_inputs: report.source_inputs.clone(),
                build_inputs: report.build_inputs.clone(),
                materialized_inputs: report.materialized_inputs.clone(),
                toolchain_inputs: report.toolchain_inputs.clone(),
                phases: report
                    .phases
                    .iter()
                    .map(|phase| ApplicationPhaseProof {
                        phase: phase.phase.clone(),
                        exit_code: phase.audit.exit_code,
                        runtime_hash: phase.runtime.executable_hash.clone(),
                        supervised: phase
                            .audit
                            .supervision
                            .as_ref()
                            .is_some_and(|capabilities| capabilities.process_tree),
                    })
                    .collect(),
                receipt_hash: run.provenance.harness_hash.clone(),
            };
            if !proof.validates(&run) {
                run.provenance.incomplete.push(issue(
                    "APPLICATION_COMPLETE_PROOF_REQUIRED",
                    "Only the complete centrally assigned native suite can deliver tasks",
                ));
            }
            artifacts.push(VerificationArtifact::new(
                APPLICATION_EXECUTION_MEDIA_TYPE,
                serde_json::to_vec(&proof)?,
            ));
        } else {
            run.provenance.incomplete.push(issue(
                "APPLICATION_ASSESSMENT_REQUIRED",
                "No central assessment",
            ));
        }
        let resolved =
            dctx0_verification::resolved_state_preconditions(&snapshot.ir, program, &run.cases);
        if !resolved.is_empty() {
            run.open_obligations
                .retain(|issue| !resolved.contains(issue));
            artifacts.push(VerificationArtifact::new(
                "application/vnd.dctx0.resolved-preconditions+json",
                serde_json::to_vec(&resolved)?,
            ));
        }
        let suites = dctx0_verification::suites::native_suite_policy_assessment(
            &snapshot.ir,
            program,
            &run.cases,
        );
        let resolved_suites = dctx0_verification::suites::resolved_native_suite_policy_obligations(
            &snapshot.ir,
            program,
            &run.cases,
        );
        run.open_obligations
            .retain(|issue| !resolved_suites.contains(issue));
        artifacts.push(VerificationArtifact::new(
            "application/vnd.dctx0.suite-policy-assessment+json",
            serde_json::to_vec(&suites)?,
        ));
        if run.result == VerificationResult::Pass {
            if let Some(problem) = run
                .provenance
                .incomplete
                .first()
                .or(run.open_obligations.first())
            {
                run.result = VerificationResult::Unknown {
                    issue: problem.clone(),
                };
            }
        }
        run.artifacts = artifacts
            .iter()
            .map(|artifact| artifact.reference.clone())
            .collect();
        let saved = self
            .store(AccessMode::ReadWrite)?
            .record_verification_run_owned_from(&self.key(), run, &artifacts, None)?;
        if !no_adopt {
            let (tasks, issues, proposal) =
                adoption::publish(self, &root, program, &saved, &artifacts)?;
            report.adoption_authority = !tasks.is_empty();
            report.adopted_tasks = tasks;
            report.adoption_issues = issues;
            report.adoption_proposal = proposal;
        }
        report.evidence = Some(saved);
        let (_, path) = crate::verification_setup::safe_file(&root, output)?;
        atomic_write(&path, &serde_json::to_vec_pretty(&report)?)?;
        Ok(report)
    }
}
